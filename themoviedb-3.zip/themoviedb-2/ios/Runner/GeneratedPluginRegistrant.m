//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<bs_flutter/BsFlutterPlugin.h>)
#import <bs_flutter/BsFlutterPlugin.h>
#else
@import bs_flutter;
#endif

#if __has_include(<bs_flutter_alert/BsFlutterAlertPlugin.h>)
#import <bs_flutter_alert/BsFlutterAlertPlugin.h>
#else
@import bs_flutter_alert;
#endif

#if __has_include(<bs_flutter_buttons/BsFlutterButtonsPlugin.h>)
#import <bs_flutter_buttons/BsFlutterButtonsPlugin.h>
#else
@import bs_flutter_buttons;
#endif

#if __has_include(<bs_flutter_card/BsFlutterCardPlugin.h>)
#import <bs_flutter_card/BsFlutterCardPlugin.h>
#else
@import bs_flutter_card;
#endif

#if __has_include(<bs_flutter_datatable/BsFlutterDatatablePlugin.h>)
#import <bs_flutter_datatable/BsFlutterDatatablePlugin.h>
#else
@import bs_flutter_datatable;
#endif

#if __has_include(<bs_flutter_inputtext/BsFlutterInputtextPlugin.h>)
#import <bs_flutter_inputtext/BsFlutterInputtextPlugin.h>
#else
@import bs_flutter_inputtext;
#endif

#if __has_include(<bs_flutter_modal/BsFlutterModalPlugin.h>)
#import <bs_flutter_modal/BsFlutterModalPlugin.h>
#else
@import bs_flutter_modal;
#endif

#if __has_include(<bs_flutter_responsive/BsFlutterResponsivePlugin.h>)
#import <bs_flutter_responsive/BsFlutterResponsivePlugin.h>
#else
@import bs_flutter_responsive;
#endif

#if __has_include(<bs_flutter_selectbox/BsFlutterSelectboxPlugin.h>)
#import <bs_flutter_selectbox/BsFlutterSelectboxPlugin.h>
#else
@import bs_flutter_selectbox;
#endif

#if __has_include(<bs_flutter_utils/BsFlutterUtilsPlugin.h>)
#import <bs_flutter_utils/BsFlutterUtilsPlugin.h>
#else
@import bs_flutter_utils;
#endif

#if __has_include(<flutter_local_notifications/FlutterLocalNotificationsPlugin.h>)
#import <flutter_local_notifications/FlutterLocalNotificationsPlugin.h>
#else
@import flutter_local_notifications;
#endif

#if __has_include(<flutter_secure_storage/FlutterSecureStoragePlugin.h>)
#import <flutter_secure_storage/FlutterSecureStoragePlugin.h>
#else
@import flutter_secure_storage;
#endif

#if __has_include(<geolocator_apple/GeolocatorPlugin.h>)
#import <geolocator_apple/GeolocatorPlugin.h>
#else
@import geolocator_apple;
#endif

#if __has_include(<google_maps_flutter_ios/FLTGoogleMapsPlugin.h>)
#import <google_maps_flutter_ios/FLTGoogleMapsPlugin.h>
#else
@import google_maps_flutter_ios;
#endif

#if __has_include(<image_picker_ios/FLTImagePickerPlugin.h>)
#import <image_picker_ios/FLTImagePickerPlugin.h>
#else
@import image_picker_ios;
#endif

#if __has_include(<package_info_plus/FLTPackageInfoPlusPlugin.h>)
#import <package_info_plus/FLTPackageInfoPlusPlugin.h>
#else
@import package_info_plus;
#endif

#if __has_include(<permission_handler/PermissionHandlerPlugin.h>)
#import <permission_handler/PermissionHandlerPlugin.h>
#else
@import permission_handler;
#endif

#if __has_include(<url_launcher_ios/FLTURLLauncherPlugin.h>)
#import <url_launcher_ios/FLTURLLauncherPlugin.h>
#else
@import url_launcher_ios;
#endif

#if __has_include(<webview_flutter_wkwebview/FLTWebViewFlutterPlugin.h>)
#import <webview_flutter_wkwebview/FLTWebViewFlutterPlugin.h>
#else
@import webview_flutter_wkwebview;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [BsFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterPlugin"]];
  [BsFlutterAlertPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterAlertPlugin"]];
  [BsFlutterButtonsPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterButtonsPlugin"]];
  [BsFlutterCardPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterCardPlugin"]];
  [BsFlutterDatatablePlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterDatatablePlugin"]];
  [BsFlutterInputtextPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterInputtextPlugin"]];
  [BsFlutterModalPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterModalPlugin"]];
  [BsFlutterResponsivePlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterResponsivePlugin"]];
  [BsFlutterSelectboxPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterSelectboxPlugin"]];
  [BsFlutterUtilsPlugin registerWithRegistrar:[registry registrarForPlugin:@"BsFlutterUtilsPlugin"]];
  [FlutterLocalNotificationsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterLocalNotificationsPlugin"]];
  [FlutterSecureStoragePlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterSecureStoragePlugin"]];
  [GeolocatorPlugin registerWithRegistrar:[registry registrarForPlugin:@"GeolocatorPlugin"]];
  [FLTGoogleMapsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTGoogleMapsPlugin"]];
  [FLTImagePickerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTImagePickerPlugin"]];
  [FLTPackageInfoPlusPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTPackageInfoPlusPlugin"]];
  [PermissionHandlerPlugin registerWithRegistrar:[registry registrarForPlugin:@"PermissionHandlerPlugin"]];
  [FLTURLLauncherPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTURLLauncherPlugin"]];
  [FLTWebViewFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTWebViewFlutterPlugin"]];
}

@end
